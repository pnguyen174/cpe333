#ifndef __DATASET_H
#define __DATASET_H
#define ARRAY_SIZE 9


#define DIM_SIZE 3 


typedef int data_t;

data_t input1_data[ARRAY_SIZE] = 
{
    0,   3,   2,   0,   3,   1,   0,   3,   2  
};

data_t input2_data[ARRAY_SIZE] = 
{
    1,   1,   0,   3,   1,   2,   0,   0,   0
};



#endif //__DATASET_H
